<?php /* header("http/1.1 403 Forbidden"); exit(); */ ?>
<h1 align="center" style="color: red; margin-top: 200px;">http/1.1 403 Forbidden</h1>