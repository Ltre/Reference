<?php
echo '--------------------START---------------------<br>';
echo '首页：禁用smarty时：加载test-start.php<br>';
echo '此模板可用的变量:<br>';
dump(get_defined_vars());
echo '--------------------END---------------------<br>';