<?php /* header("HTTP/1.0 404 Not Found"); exit(); */ ?>
<h1 align="center" style="color: red; margin-top: 200px;">HTTP/1.0 404 Not Found</h1>