<?php
echo '--------------------START---------------------<br>';
echo '禁用smarty时：加载test-else.php<br>';
echo '此模板可用的变量:<br>';
dump(get_defined_vars());
echo '--------------------END---------------------<br>';