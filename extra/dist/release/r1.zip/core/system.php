<?php
define('CLI_DEBUG', 0);
CLI_DEBUG && require 'cli_debug.php';
define('DI_CORE_PATH', 'core/');
define('DI_BASE_PATH', DI_CORE_PATH . 'base/');
define('DI_CONFIG_PATH', DI_CORE_PATH . 'config/');
define('DI_ENTITY_PATH', DI_CORE_PATH . 'entity/');
define('DI_MODEL_PATH', DI_CORE_PATH . 'model/');
define('DI_FILTER_PATH', DI_CORE_PATH . 'filter/');
define('DI_INJECT_PATH', DI_CORE_PATH . 'inject/');
define('DI_DO_PATH', DI_CORE_PATH . 'do/');
define('DI_SERVICE_PATH', DI_CORE_PATH . 'service/');
define('DI_TPL_PATH', DI_CORE_PATH . 'tpl/');
define('DI_LET_PATH', DI_CORE_PATH . 'let/');
define('DI_SETTING_PATH', DI_CORE_PATH . 'setting/');
define('DI_EXT_PATH', DI_CORE_PATH . 'ext/');
define('DI_DATA_PATH', DI_CORE_PATH . 'data/');

class DIIncludeConfig {

    static function DI_SPCL_AUTOLOAD_PATH() {
        return array(
            'model' => DI_MODEL_PATH . '{name}.model.php',
            'filter' => DI_FILTER_PATH . '{name}.filter.php',
            'inject' => DI_INJECT_PATH . '{name}.inject.php',
            'do' => DI_DO_PATH . '{name}.do.php',
            'service' => DI_SERVICE_PATH . '{name}.service.php'
        );
    }

    static function DI_NOSPCL_AUTOLOAD_PATH() {
        return array(
            'entity' => DI_ENTITY_PATH . '{name}.php'
        );
    }

}

foreach (array('const', 'define', 'urlshell', 'filtermap', 'database') as $config){
    require DI_CONFIG_PATH . "$config.php";
}

header('Content-type:text/html; charset=utf-8');
ob_start();
date_default_timezone_set('PRC');
session_start();
if (!defined('DI_SESSION_PREFIX')) define('DI_SESSION_PREFIX', 'di_');
if (!defined('DI_LET_ENABLED')) define('DI_LET_ENABLED', true);
if (!defined('DI_URLREWRITE_ENABLE')) define('DI_URLREWRITE_ENABLE', false);
if (!defined('DI_FILTRATE_DOPARAMS')) define('DI_FILTRATE_DOPARAMS', false);
if (!defined('DI_DEBUG_MODE')) define('DI_DEBUG_MODE', true);
if (!defined('DI_IO_RWFUNC_ENABLE')) define('DI_IO_RWFUNC_ENABLE', false);
if (!defined('DI_CLASS_AUTOLOAD_STRICT')) define('DI_CLASS_AUTOLOAD_STRICT', true);
if (!defined('DI_VIEW_AUTOLOAD')) define('DI_VIEW_AUTOLOAD', true);
if (!defined('DI_SMARTY_ENABLE')) define('DI_SMARTY_ENABLE', false);
if (!defined('DI_LOG_PATH')) define('DI_LOG_PATH', DI_DATA_PATH . 'log/');
if (!defined('DI_PAGE_400')) define('DI_PAGE_400', DI_TPL_PATH . '400.php');
if (!defined('DI_PAGE_403')) define('DI_PAGE_403', DI_TPL_PATH . '403.php');
if (!defined('DI_PAGE_404')) define('DI_PAGE_404', DI_TPL_PATH . '404.php');
if (!defined('DI_PAGE_503')) define('DI_PAGE_503', DI_TPL_PATH . '503.php');
if (DI_DEBUG_MODE) {
    ini_set("display_errors", "On");
    error_reporting(E_ALL & ~E_STRICT);
} else {
    ini_set("display_errors", "Off");
    error_reporting(E_ALL & ~(E_STRICT | E_NOTICE));
}
class DIException extends Exception {

    function __construct($message, $code = 0, Exception $previous = NULL) {
        if (DI_DEBUG_MODE) {
            parent::__construct($message, $code, $previous);
        } else {
            if (DI_IO_RWFUNC_ENABLE) {
                $time = date('Y-m-d H:i:s');
                $file = DI_LOG_PATH . 'log_' . date('Y-m-d') . '.txt';
                $link = fopen($file, 'a+');
                fwrite($link, $time . "    {$_SERVER['SERVER_PROTOCOL']}    {$_SERVER['SERVER_NAME']}${(80==$_SERVER['SERVER_PORT']?'':':'.$_SERVER['SERVER_PORT'])}{$_SERVER['REQUEST_URI']}    $message\r\n");
            } else {
            }
            require DI_PAGE_503;
        }
    }

}
class DIInclude {

    public static function includeAllPHP($dir) {
        foreach (explode('|', $dir) as $path) {
            if (in_array($path, array(
                '',
                './',
                '../'
            )) || false !== strpos($path, './')) continue;
            $path = trim(trim($path), '/');
            $path .= '/';
            self::parsePhpDirFromLibDirAndAutoIncludeTheir($path);
        }
    }

    public static function parseXxxFormatFromDirAndAutoIncludeTheir($xxxFormatDir, $secondExtname, $suffix = null) {
        foreach (glob(APPROOT . $xxxFormatDir . '{A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z}*' . $suffix . '.' . $secondExtname . '.php', GLOB_BRACE) as $xxxFormatDirFile) {
            require $xxxFormatDirFile;
        }
    }

    private static function parsePhpDirFromLibDirAndAutoIncludeTheir($path, $layer = 0) {
        if (is_dir($path) && ($dh = opendir($path))) {
            while (false !== ($file = readdir($dh))) {
                if (in_array($file, array(
                    '.',
                    '..'
                ))) continue;
                if (is_dir($path . $file)) {
                    self::parsePhpDirFromLibDirAndAutoIncludeTheir($path . $file . '/', $layer + 1);
                } else {
                    if (0 !== preg_match('/\.php$/', $file)) require $path . $file;
                }
            }
            closedir($dh);
        }
    }

}

function __autoload($class_name) {
    $aap = DIIncludeConfig::DI_SPCL_AUTOLOAD_PATH();
    $pos = false;
    $name = '';
    $path = '';
    foreach ($aap as $i => $p) {
        $pos = strripos($class_name, $i);
        if (false !== $pos) {
            $name = substr($class_name, 0, $pos);
            $path = str_replace('{name}', $name, $p);
            file_exists($path) && require $path;
            break;
        }
    }
    if (false === $pos) {
        $aap = DIIncludeConfig::DI_NOSPCL_AUTOLOAD_PATH();
        $name = &$class_name;
        foreach ($aap as $i => $p) {
            $path = str_replace('{name}', $name, $p);
            if (file_exists($path)) {
                require $path;
                break;
            }
        }
    }
    !class_exists($class_name, false) && !DI_CLASS_AUTOLOAD_STRICT && DIInclude::includeAllPHP(DI_EXT_PATH);
    if (!class_exists($class_name, false)) {
        eval("class $class_name {}");
    }
}
spl_autoload_register('__autoload');

function import($path = '*', $inc = DI_EXT_PATH) {
    $path = strval($path);
    $inc = strval($inc);
    empty($path) && $path = '/';
    (strlen($inc) - 1 === strrpos($inc, '/')) || $inc .= '/';
    if ('*' != $path) {
        $path = trim($path, '*');
        $len = strlen($path);
        $path .= (substr($path, $len - 1) == '/') ? '' : '.php';
        $inc .= $path;
    }
    if (!DIRuntime_Imported::push($inc)) {return false;}
    if (is_file($inc)) {
        return require_once $inc;
    } else if (is_dir($inc)) {
        DIInclude::includeAllPHP($inc);
    } else {
        $d = debug_backtrace();
        $msg = "import()操作错误：文件或目录[ $inc ]不存在<br>错误源：{$d[0]['file']}::第{$d[0]['line']}行import()处<br>";
        throw new DIException($msg);
    }
}

function invoke_method($obj, $method, $args = array()) {
    if (!is_object($obj)) {throw new DIException("{$obj}对象不存在或非对象类型");}
    if (method_exists($obj, $method)) {
        return call_user_func_array(array(
            $obj,
            $method
        ), $args);
    } else if (array_key_exists($method, get_object_vars($obj))) {
        if (is_callable(array(
            $obj,
            $method
        ))) {
            call_user_func_array(array(
                $obj,
                $method
            ), $args);
        } else {
            throw new DIException('成员方法访问操作：' . get_class($obj) . ' -> ' . $method . '成员变量不具备callable特性，不能调用<br>');
        }
    } else {
        throw new DIException(get_class($obj) . "对象的方法名[ {$method} ]不存在");
    }
}

function invoke_func($func, $args = array()) {
    call_user_func_array($func, $args);
}

function ref_arr($arr) {
    if (version_compare(PHP_VERSION, '5.3.0') >= 0) {
        $refs = array();
        foreach ($arr as $key => $value)
            $refs[$key] = &$arr[$key];
        return $refs;
    }
    return $arr;
}

function array_unset(&$array, $key) {
    $value = $array[$key];
    unset($array[$key]);
    return $value;
}

function params_to_str($num) {
    $params = '';
    for ($i = 0; $i < $num; $i++)
        $params .= '$param' . $i . ',';
    $params = rtrim($params, ',');
    return $params;
}

function create_class($name, $abstract = false, $extends = null, $implements = null, $vars = array(), $funcs = array()) {
    $abstract = $abstract === true ? 'abstract' : '';
    $code = "$abstract class $name ";
    empty($extends) || $code .= "extends $extends ";
    empty($implements) || $code .= "implements $implements ";
    $code .= '{';
    foreach (array(
        'vars',
        'funcs'
    ) as $v) {
        $$v = $$v === null || !is_array($$v) ? array() : $$v;
        foreach ($$v as $item) {
            $code .= $item;
        }
    }
    $code .= '}';
    eval($code);
    if (!class_exists('DITempObject', false)) {
        class DITempObject extends DIBase {
            var $class_name;

            function __construct($class_name) {
                $this->class_name = $class_name;
            }

            function newInstance($param_arr = array()) {
                $clazz = $this->class_name;
                $rc = new ReflectionClass($clazz);
                return $rc->newInstanceArgs($param_arr);
            }
        
        }
    }
    return new DITempObject($name);
}

function session($name = null, $value = null, $prefix = null, $private = true) {
    $num = count(func_get_args());
    $prefix = null === $prefix ? DI_SESSION_PREFIX : $prefix;
    if (2 === $num) {
        $name = func_get_arg(0);
        $value = func_get_arg(1);
        $_SESSION[$prefix . $name] = $value;
    } else if (1 === $num) {
        if (!isset($_SESSION[$prefix . $name])) {throw new DIException("试图获取不存在的会话 [ {$prefix}{$name} ] ");}
        return $_SESSION[$prefix . $name];
    } else if (0 === $num) {
        if ($private) {
            $zezzion = array();
            foreach ($_SESSION as $i => $s) {
                if (0 === strpos($i, $prefix) && $i != $prefix) $zezzion[$i] = $s;
            }
            return $zezzion;
        } else {
            return $_SESSION;
        }
    }
}

function session_exists($name, $prefix = null) {
    $prefix = null === $prefix ? $GLOBALS['session_prefix'] : $prefix;
    return isset($_SESSION[$prefix . $name]);
}

function dump($var, $exit = false) {
    $output = print_r($var, true);
    if (!DI_DEBUG_MODE) return error_log(str_replace("\n", '', $output));
    $content = "<div align=left><pre>\n" . htmlspecialchars($output) . "\n</pre></div>\n";
    echo "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
    echo "</head><body>{$content}</body></html>";
    if ($exit) exit();
}
interface DIEventListener {

}
interface DIEvent_ObjCreateListener extends DIEventListener {

    function beforeObjCreate();

    function onObjCreate();

    function afterObjCreate();

}
interface DIEvent_ObjCallListener extends DIEventListener {

    function beforeObjCall();

    function onObjCall();

    function afterObjCall();

}
interface DIEvent_ClassCallListener extends DIEventListener {

    function beforeClassCall();

    function onClassCall();

    function afterClassCall();

}
interface DIEvent_GetVariableListener extends DIEventListener {

    function beforeGetVariable();

    function onGetVariable();

    function afterGetVariable();

}
interface DIEvent_GetStaticVariableListener extends DIEventListener {

    function beforeGetStaticVariable();

    function onGetStaticVariable();

    function afterGetStaticVariable();

}
interface DIEvent_SetVariableListener extends DIEventListener {

    function beforeSetVariable();

    function onSetVariable();

    function afterSetVariable();

}
interface DIEvent_SetStaticVariableListener extends DIEventListener {

    function beforeSetStaticVariable();

    function onSetStaticVariable();

    function afterSetStaticVariable();

}
interface DIEvent_AppendVariableListener extends DIEventListener {

    function beforeAppendVariable();

    function onAppendVariable();

    function afterAppendVariable();

}
interface DIEvent_CallFuncListener extends DIEventListener {

    function beforeCallFunc();

    function onCallFunc();

    function afterCallFunc();

}
interface DIEvent_CallStaticFuncListener extends DIEventListener {

    function beforeCallStaticFunc();

    function onCallStaticFunc();

    function afterCallStaticFunc();

}
interface DIEvent_AppendFuncListener extends DIEventListener {

    function beforeAppendFunc();

    function onAppendFunc();

    function afterAppendFunc();

}
interface DIEvent_DestroyListener extends DIEventListener {

    function beforeDestroy();

    function onDestroy();

    function afterDestroy();

}
abstract class DIEvent {
    protected $eventListeners = array();
    protected $eventType;

    function attachEventListener(DIEventListener $ael) {
        array_push($this->eventListeners, $ael);
    }

    function detachEventListener(DIEventListener $ael) {
        $this->eventListeners = array_filter($this->eventListeners, function ($var) use($ael) {
            return $var != $ael;
        });
    }

    function notify() {
        foreach ($this->eventListeners as $el) {
            foreach (get_class_methods($el) as $m) {
                call_user_func_array(array(
                    $el,
                    $m
                ), array());
            }
        }
    }

}
abstract class DIBase extends DIEvent {
    protected $_before = array();
    protected $_action = array();
    protected $_after = array();
    protected $_lambda = array();
    protected $_vars = array();
    protected $isStrict = true;

    function __construct() {
        $args = func_get_args();
        $this->isStrict = (bool) (array_pop($args));
    }

    public function getVitualVars() {
        return $this->_vars;
    }

    public function getLambdas() {
        return $this->_lambda;
    }

    function __call($name, $args) {
        $interfaces = class_implements($this);
        $has = in_array('DIEvent_CallFuncListener', $interfaces);
        $has && invoke_method($this, 'beforeCallFunc', array());
        $this->_invoke($name, $args);
        $has && invoke_method($this, 'afterCallFunc', array());
    }

    protected final function _invoke($name, $args) {
        if (method_exists($this, $name)) {
            call_user_func_array(array(
                $this,
                $name
            ), $args);
        } elseif (array_key_exists($name, get_object_vars($this))) {
            if (is_callable(array(
                $this,
                $name
            ))) {
                call_user_func_array(array(
                    $this,
                    $name
                ), $args);
            } else {
                throw new DIException('成员方法访问操作：' . get_class($this) . ' -> ' . $name . '成员变量不具备callable特性，不能调用<br>');
            }
        } elseif (array_key_exists($name, $this->_vars)) {
            throw new DIException('成员方法访问操作：所访问的虚拟成员[ ' . get_class($this) . '->' . "$name ]不可作为callable回调函数<br>");
        } elseif (array_key_exists($name, $this->_lambda)) {
            call_user_func_array($this->_lambda[$name], $args);
        }
    }

    final function __set($name, $value) {
        if (is_callable($value)) {
            if (method_exists($this, $name)) {
                throw new DIException('动态设置成员方法操作：在' . get_class($this) . "的方法[ $name ]已存在，不允许覆盖<br>");
            } else if (array_key_exists($name, $this->_vars)) {
                throw new DIException('动态设置成员方法操作：在' . get_class($this) . "中已存在与[ $name ]同名的虚拟成员变量<br>");
            } else {
                $this->_lambda[$name] = $value;
            }
        } else {
            if (array_key_exists($name, get_object_vars($this))) {
                throw new DIException('动态设置成员变量操作：在' . get_class($this) . "的成员变量/常量[ $name ]已存在，不允许覆盖<br>");
            } else if (array_key_exists($name, $this->_lambda)) {
                throw new DIException('动态设置成员变量操作：在' . get_class($this) . "中已存在与[ $name ]同名的虚拟成员方法<br>");
            } else {
                $this->_vars[$name] = $value;
            }
        }
    }

    final function __get($name) {
        if (array_key_exists($name, get_object_vars($this)) || array_key_exists($name, get_object_vars($this))) {
            throw new DIException('获取成员变量/方法操作：' . get_class($this) . "中的成员[ $name ]受protected保护，不允许直接读取<br>");
        } else if (array_key_exists($name, $this->_lambda)) {
            return $this->_lambda[$name];
        } else if (array_key_exists($name, $this->_vars)) {
            return $this->_vars[$name];
        } else {
            throw new DIException('获取成员变量/方法操作：' . get_class($this) . "中不存在名为[ $name ]的成员<br>");
        }
    }

    final function __unset($name) {
        if (array_key_exists($name, get_object_vars($this))) {
            throw new DIException('动态撤销成员变量/方法操作：' . get_class($this) . "的固有成员变量/常量[ $name ]不允许删除<br>");
        } else if (method_exists($this, $name)) {
            throw new DIException('动态撤销成员变量/方法操作：' . get_class($this) . "的固有成员方法[ $name ]不允许删除<br>");
        } else if (!array_key_exists($name, $this->_vars) && !array_key_exists($name, $this->_lambda)) {
            throw new DIException('动态撤销成员变量/方法操作：在' . get_class($this) . "中，[ $name ]成员不存在<br>");
        } else {
            unset($this->_lambda[$name]);
        }
    }

    function __isset($name) {
    }

    function __clone() {
    }

}
abstract class DIContext extends DIBase {
    private $contexts = array();

    public function setContext($index, $item) {
        $this->contexts[$index] = $item;
    }

    public function getContext($index) {
        if (!isset($this->contexts[$index])) throw new DIException("该索引 [ $index ]在系统上下文中不存在");
        return $this->contexts[$index];
    }

    public function unsetContext($index) {
        if (!isset($this->contexts[$index])) throw new DIException("该索引 [ $index ]在系统上下文中不存在");
        array_unset($this->contexts, $index);
    }

}
class DIContext_Inject extends DIContext {

    public function addInject(DIBase $obj, $memberFuncName, $callback, array $callback_args = array(), $isAfter = false) {
        $index = get_class($obj) . '->' . $memberFuncName;
        $item = inject($obj, $memberFuncName, $callback, $callback_args, $isAfter);
        $this->setContext($index, $item);
    }

    public function removeInject(DIBase $obj, $memberFuncName) {
        $index = get_class($obj) . '->' . $memberFuncName;
        $this->unsetContext($index);
    }

}
class DIRuntime extends DIBase {
    private static $pool = array(); // 存储池
    protected static function getMaxNum($prefix) {
        $pool = parent::getRuntime();
        $keys = array_keys($pool);
        $max = false;
        foreach ($keys as $k) {
            $num = substr_replace($k, '', 0, strrpos($k, $prefix) + 1);
            if ((false === $max || $max < $num) && is_numeric($num)) $max = $num;
        }
        return $max ? $max : 0;
    }

    static function addItem($index, $item) {
        if (isset(self::$pool[$index])) throw new DIException("该索引 [ $index ]在系统运行时中已存在");
        self::$pool[$index] = $item;
    }

    static function getItem($index) {
        if (!isset(self::$pool[$index])) return null;
        return self::$pool[$index];
    }

    static function updItem($index, $item) {
        if (!isset(self::$pool[$index])) throw new DIException("该索引 [ $index ]在系统运行时中不存在");
        self::$pool[$index] = $item;
    }

    static function delItem($index) {
        if (!isset(self::$pool[$index])) throw new DIException("该索引 [ $index ]在系统运行时中不存在");
        array_unset(self::$pool, $index);
    }

    static function hasIndex($index) {
        return isset(self::$pool[$index]);
    }

    static function hasItem($item) {
        return in_array($item, self::$pool);
    }

    static function mergeNewItems($items) {
        self::$pool += $items;
    }

    static function getRuntime() {
        return self::$pool;
    }

}
class DIRuntime_Imported extends DIRuntime {
    const INDEX = 'imported';

    private static function initPool() {
        $keyexist = parent::hasIndex(self::INDEX);
        $ispool = $keyexist ? is_array(parent::getItem(self::INDEX)) : false;
        if (!$ispool) parent::addItem(self::INDEX, array());
    }

    private static function isPushed($path) {
        $imported = parent::getItem(self::INDEX);
        $flag = false;
        foreach ($imported as $i) {
            if (!is_string($i)) continue;
            if (0 === strpos($i, $path) || 0 === strpos($path, $i)) {
                $flag = true;
                break;
            }
        }
        return $flag;
    }

    static function push($path) {
        self::initPool();
        if (self::isPushed($path)) {return false;}
        $imported = parent::getItem(self::INDEX);
        array_push($imported, $path);
        parent::updItem(self::INDEX, $imported);
        return true;
    }

    static function imported() {
        return parent::getItem(self::INDEX);
    }

}
class DIConfig {

}
abstract class DIEntity extends DIBase {

}
interface DIModelTemplate {

    function getDBConfig();

    function connect($config);

}
abstract class DIModel extends DIBase implements DIModelTemplate {
    protected $_table = '';
    protected static $_conn = null;
    protected static $_cache_rs = array();

    function __construct() {
        self::$_conn or self::_init();
    }

    private function _init() {
        $config = $this->getDBConfig();
        self::$_conn = $this->connect($config);
    }

    function getConn() {
        return self::$_conn;
    }

    function query($sql, $condition = array()) {
    }

    function insert() {
    }

    function update() {
    }

    function delete() {
    }

}
interface DIFilter {

    function doFilter();

}
class DIFilterUtil extends DIBase {

    static function execGlobalFilter() {
        $shell = DIRuntime::getItem('shell');
        $isDefault = !strcasecmp($shell, DIUrlShell::$_default_shell);
        if ($isDefault) {return;}
        $list = DIFilterMap::getGlobalFilters();
        $execlist = array();
        foreach ($list as $k => &$l) {
            if (!is_array($l)) continue;
            $exclude = false;
            foreach ($l as $ll) {
                if (DI_DO_MODULE == $ll) {
                    $exclude = true;
                    break;
                }
                if (DI_DO_MODULE . '/' . DI_DO_FUNC == $ll) {
                    $exclude = true;
                    break;
                }
            }
            if ($exclude) continue;
            $execlist[] = $k;
        }
        self::invokeFilter($execlist);
    }

    static function execSpecialFilter($spot) {
        $validate = is_string($spot) && false !== strpos($spot, '/') && 2 == count($ex = explode('/', $spot));
        if (!$validate) {throw new DIException('DIFilterUtil::exec() FILE ' . __FILE__ . ' LINE ' . __LINE__ . ' $spot参数错误，格式必须为[Do名/方法]，当前序列化值：' . serialize($spot));}
        $need = DIFilterMap::$need;
        $ns = DIFilterMap::getNeedsMap();
        $ws = DIFilterMap::getWithoutMap();
        $lneed = self::loop($ns, $spot, 'getNeedsMap');
        $lwithout = self::loop($ws, $spot, 'getWithoutMap');
        $needlist = $lneed['list'];
        $withoutlist = $lwithout['list'];
        if (!$need) {
            foreach ($withoutlist as &$w) {
                while (is_int($index = array_search($w, $needlist))) {
                    array_unset($needs, $index);
                }
            }
        }
        $sortlist = self::setSort($needlist, $spot);
        self::invokeFilter($sortlist);
    }

    static private function loop($loop, $spot, $loopname) {
        if (!is_array($loop)) {throw new DIException("过滤规则[ {$loopname} ]配置格式错误");}
        $list = array();
        $flag = false;
        foreach ($loop as $i => &$l) {
            if (!is_array($l)) {throw new DIException("过滤规则[ {$loopname} - {$i} ]配置格式错误");}
            if (in_array($spot, $l)) {
                $flag = true;
                $list[] = $i;
                continue;
            }
            foreach ($l as $k => &$ll) {
                if (!is_string($ll)) {throw new DIException("过滤器作用点[ {$loopname} - {$i} - {$k} ]配置格式错误");}
                $ex = explode('/', $spot);
                if ($ll == $ex[0]) {
                    $flag = true;
                    $list[] = $i;
                    continue;
                }
            }
        }
        return array(
            'flag' => $flag,
            'list' => $list
        );
    }

    static private function setSort($list, $spot) {
        $spSort = DIFilterMap::getSpecialFilterSort();
        $dfSort = DIFilterMap::getDefaultFilterSort();
        $sort = isset($spSort[$spot]) ? $spSort[$spot] : $dfSort;
        foreach ($sort as $i => $s) {
            $index = array_search($s, $list);
            if (is_int($index)) {
                array_unset($list, $index);
            } else {
                array_unset($sort, $i);
            }
        }
        foreach ($list as $l) {
            array_push($sort, $l);
        }
        return $sort;
    }

    static private function invokeFilter($list) {
        foreach ($list as &$filter) {
            $filter .= 'Filter';
            invoke_method(new $filter(), 'doFilter');
        }
    }

}
abstract class DIInject extends DIBase {
    protected $_do;

    final function __construct(DIDo $_do) {
        $this->_do = $_do;
    }

}

function injectObjFunc($obj, $callback, $memberFuncName = null, $callback_args = array()) {
    if (!is_object($obj)) return -1;
    if (!is_callable($callback)) return -2;
    if (!$memberFuncName && !method_exists($obj, $memberFuncName)) return -3;
    if (!is_array($callback_args)) return -4;
    try {
        $obj->__call = function ($name, $args) use($obj, $callback, $memberFuncName, $callback_args) {
            $bind = false;
            if (!$memberFuncName) {
                $bind = true;
            } else if (!strcmp($name, $memberFuncName)) {
                $bind = true;
            }
            if ($bind) call_user_func_array($callback, $callback_args);
            call_user_func_array(array(
                $obj,
                $name
            ), $args);
        };
    } catch (DIException $e) {
        throw $e;
    }
    return 0;
}

function inject(DIBase $obj, $memberFuncName, $callback, array $callback_args = array(), $isAfter = false) {
    if (!is_object($obj)) return -1;
    if (!is_callable($callback)) return -2;
    if (!$memberFuncName && !method_exists($obj, $memberFuncName)) return -3;
    if (!is_array($callback_args)) return -4;
    $clazz = get_class($obj);
    $rc = new ReflectionClass($clazz);
    $num = $rc->getMethod($memberFuncName)
        ->getNumberOfParameters();
    $vars = array(
        'var $callback;',
        'var $callback_args;'
    );
    $params = params_to_str($num);
    $funcs = array(
        "function $memberFuncName ( $params ){
        \$args = func_get_args();
        " . ($isAfter ? '' : "call_user_func_array(\$this->callback, \$this->callback_args);") . "
        //call_user_func_array(array('$clazz', '$memberFuncName'),\$args);//方式1
        //parent::{$memberFuncName}( $params );//方式2
        call_user_func_array('parent::{$memberFuncName}', \$args);//方式3
        " . (!$isAfter ? '' : "call_user_func_array(\$this->callback, \$this->callback_args);") . "
		}",
        'function __construct(){
			$args = func_get_args();
			$last=$args[count($args)-1];
			$this->callback = $last[0];
			$this->callback_args = $last[1];
			call_user_func_array("parent::__construct", $args);
        }'
    );
    $tmpObj = create_class("tmp{$clazz}", false, $clazz, null, $vars, $funcs)->newInstance(array(
        array(
            $callback,
            $callback_args
        )
    ));
    return $tmpObj;
}

function inject_full(DIBase $obj, $memberFuncName, array $before = array(), array $after = array()) {
    $before = empty($before) || 2 != count($before) ? array(
        function () {
        },
        array()
    ) : $before;
    $after = empty($after) || 2 != count($after) ? array(
        function () {
        },
        array()
    ) : $after;
    if (!is_object($obj)) return -1;
    if (!(2 == count($before) && is_callable($before[0]) || 2 == count($after) && is_callable($after[0]))) return -2;
    if (!$memberFuncName && !method_exists($obj, $memberFuncName)) return -3;
    if (!(2 == count($before) && is_array($before[1]) || 2 == count($after) && is_array($after[1]))) return -4;
    $clazz = get_class($obj);
    $rc = new ReflectionClass($clazz);
    $num = $rc->getMethod($memberFuncName)
        ->getNumberOfParameters();
    $vars = array(
        'var $bf_callback;',
        'var $bf_callback_args;',
        'var $af_callback;',
        'var $af_callback_args;'
    );
    $params = params_to_str($num);
    $funcs = array(
        "function $memberFuncName ( $params ){
            \$args = func_get_args();
            call_user_func_array(\$this->bf_callback, \$this->bf_callback_args);
            //call_user_func_array(array('$clazz', '$memberFuncName'),\$args);//方式1
            //parent::{$memberFuncName}( $params );//方式2
            call_user_func_array('parent::{$memberFuncName}', \$args);//方式3
    		call_user_func_array(\$this->af_callback, \$this->af_callback_args);
    	}",
        'function __construct(){
    		$args = func_get_args();
    		$last1 = $args[count($args)-2];
    		$this->bf_callback = $last1[0];
    		$this->bf_callback_args = $last1[1];
    		$last2 = $args[count($args)-1];
    		$this->af_callback = $last2[0];
    		$this->af_callback_args = $last2[1];
    		call_user_func_array("parent::__construct", $args);
        }'
    );
    $tmpObj = create_class("tmp{$clazz}", false, $clazz, null, $vars, $funcs)->newInstance(array(
        $before,
        $after
    ));
    return $tmpObj;
}

function inject_dymic() {
}

function inject_func($func, $callback, $callback_args = array(), $isAfter = false) {
}
abstract class DIDo extends DIBase {
    protected $_name;
    protected $_inject;
    protected $_bridge = array();
    protected $_tpl;

    protected function tpl($tpl_name = null, $return = false) {
        if (null === $tpl_name) {
            $do_name = substr(get_class($this), 0, strripos(get_class($this), 'Do'));
            $debug_backtrace = debug_backtrace();
            $func_name = $debug_backtrace[1]['function'];
            if (method_exists($do_name . 'Do', $func_name)) {
            }
            $tpl_name = strtolower($do_name . '-' . $func_name);
        }
        if (is_file($tpl_name)) {throw new DIException("模板文件[ $tpl_name ]不存在");}
        if (DI_SMARTY_ENABLE) return $this->_tpl->showWithSmarty($tpl_name . '.html', $return);
        else return $this->_tpl->showWithGeneral($tpl_name . '.php');
    }

    final function __construct() {
        $clazz = get_class($this);
        $this->_name = substr($clazz, 0, strripos($clazz, 'Do'));
        $inject = $this->_name . 'Inject';
        $this->_inject = new $inject($this);
        $this->_tpl = new DITpl($this);
    }

    final function __call($name, $args) {
        if ($this->_inject) {
            $has_before = 'has_before';
            $has_on = 'has_on';
            $has_after = 'has_after';
            $before = 'before';
            $on = 'on';
            $after = 'after';
            foreach (array(
                'before',
                'on',
                'after'
            ) as $prep) {
                $hasPrep = 'has_' . $prep;
                $$prep .= ucfirst($name);
                $$hasPrep = method_exists($this->_inject, $$prep);
            }
            $has_before && call_user_func_array(array(
                $this->_inject,
                $before
            ), array(
                $this->_bridge
            ));
            $on_ret = $has_on ? invoke_method($this->_inject, $on, array(
                $this->_bridge
            )) : array(); // 获取onXxx()配置的注入function数组
            $on_ret = $has_on ? call_user_func_array(array(
                $this->_inject,
                $on
            ), array(
                $this->_bridge
            )) : array(); // 获取onXxx()配置的注入function数组
            $this->_invoke($name, array_merge($args, array(
                $on_ret
            ))); // 注入环绕代码数组到参数中，并执行XxxDo方法
            $has_after && call_user_func_array(array(
                $this->_inject,
                $after
            ), array(
                $this->_bridge
            ));
        } else {
            $this->_invoke($name, $args);
        }
    }

}
abstract class DIService extends DIBase {

}
class DITpl extends DIBase {
    private $_smarty;
    private $_auto_show;
    private $_do;

    public function __construct(DIDo $_do) {
        $this->_do = $_do;
        import('smarty/Smarty.class'); // 引入模板引擎
    }

    public function preoutput() {
        header('Content-type: text/html; charset=utf-8');
        ob_start();
    }

    public function showWithSmarty($tpl_name, $return = false) {
        $this->smarty();
        $this->_smarty->assign($this->_do->getVitualVars());
        $this->_smarty->assign(get_object_vars($this->_do));
        if ($return) {
            return $this->_smarty->fetch($tpl_name);
        } else {
            $this->preoutput();
            $this->_smarty->display($tpl_name);
        }
    }

    public function showWithGeneral($tpl_name) {
        $this->preoutput();
        extract($this->_do->getVitualVars());
        extract(get_object_vars($this->_do));
        require DI_TPL_PATH . $tpl_name;
    }

    public function smarty() {
        if (!$this->_smarty) {
            $this->_smarty = new Smarty();
            $this->_smarty->template_dir = DI_TPL_PATH;
            $this->_smarty->compile_dir = DI_DATA_PATH . 'cache';
            $this->_smarty->cache_dir = DI_DATA_PATH . 'cache';
            $this->_smarty->left_delimiter = '{';
            $this->_smarty->right_delimiter = '}';
            $this->_smarty->auto_literal = true;
            $this->_smarty->default_modifiers = array(
                'escape:"html"'
            );
        }
    }

}
class DILet extends DIBase {

}

function let($path, $other = null) {
    if (!DI_LET_ENABLED) {throw new DIException('需要先启用LET小程序支持，详见DI_LET_ENABLED @ __let.php');}
    $args = func_get_args();
    $num = func_num_args();
    if (1 === $num) {
        import(strval($args[0]), DI_LET_PATH);
    } else if (2 === $num) {
        $path = DI_LET_PATH . trim(strval($args[0]), '/') . '.php';
        if (is_string($args[1])) {
            $code = "<?php {$args[1]}";
            if (false === file_put_contents($path, $code)) {
                return -1;
            } else {
                return 0;
            }
        } else if (null === $args[1]) {
            if (is_file($path)) {
                unlink($path);
                $dir = dirname($path);
                if (0 === count(glob($dir))) {
                    rmdir($dir);
                }
            }
        } else {
        }
    } else {
    }
}

function let_exists($path) {
    if (!DI_LET_ENABLED) {throw new DIException('需要先启用LET小程序支持，详见DI_LET_ENABLED @ __let.php');}
    $path = DI_LET_PATH . trim(strval($path), '/') . '.php';
    return is_file($path);
}
final class DIRoute {

    public function route($get) {
        $rt = $this->analyse($get);
        DIRuntime::mergeNewItems($rt);
        $type = &$rt['reqtype'];
        $isal = &$rt['isallow'];
        $req = &$rt['request'];
        if ('do' == $type && $isal) {
            define('DI_LET_CURRENT', '');
            define('DI_DO_MODULE', $req['do']);
            define('DI_DO_FUNC', $req['func']);
            DIFilterUtil::execGlobalFilter();
            DIFilterUtil::execSpecialFilter(DI_DO_MODULE . '/' . DI_DO_FUNC);
            $do = DI_DO_MODULE . 'Do';
            invoke_method(new $do(), DI_DO_FUNC, $req['args']);
        } else if ('let' == $type && $isal) {
            {
                define('DI_DO_MODULE', '');
                define('DI_DO_FUNC', '');
            }
            define('DI_LET_CURRENT', $req['path']);
            let(DI_LET_CURRENT);
        } else {
            require DI_PAGE_400;
        }
    }

    public function analyse($get) {
        $shell = $this->getShell($get);
        $runtime['shell'] = $shell;
        if ($this->is_do($shell)) {
            $shell_arr = explode('/', trim($shell, '/'));
            $do = ucfirst(array_shift($shell_arr));
            $func = array_shift($shell_arr);
            $runtime['isallow'] = $this->cmpdo($do, $func, $shell_arr);
            $runtime += array(
                'reqtype' => 'do',
                'request' => array(
                    'do' => $do,
                    'func' => $func,
                    'args' => $shell_arr
                )
            );
        } else if ($this->is_let($shell)) {
            $path = trim(str_replace('|', '/', $shell), '/');
            $file = DI_LET_PATH . $path . '.php';
            $runtime['isallow'] = is_file($file) && $this->cmplet($path);
            $runtime += array(
                'reqtype' => 'let',
                'request' => array(
                    'path' => $path
                )
            );
        } else {
            $runtime += array(
                'isallow' => false,
                'reqtype' => 'else',
                'request' => null
            );
        }
        return $runtime;
    }

    private function getShell($get) {
        $shell = DIUrlShell::$_default_shell;
        foreach ($get as $k => $g) {
            if ('' === $g) {
                $shell = $k;
                break;
            }
        }
        return $shell;
    }

    private function is_do($shell) {
        $re1 = '^((?:[a-z][a-z0-9_]*))';
        $re2 = '(\\/)';
        $re3 = '((?:[a-z][a-z0-9_]*))';
        $re4 = '((?:\\/[\\w\\.\\-]+)*)';
        $rs = preg_match("/" . $re1 . $re2 . $re3 . $re4 . "/is", $shell);
        return false !== $rs && 0 < $rs;
    }

    private function is_let($shell) {
        $re1 = '^(\\|)(\\|)';
        $re2 = '((?:[a-z0-9_-]+(\\|))*)';
        $re3 = '((?:[a-z0-9_-]*))+$';
        $rs = preg_match("/" . $re1 . $re2 . $re3 . "/is", $shell);
        return false !== $rs && 0 < $rs;
    }

    private function cmpdo($do, $func, $args) {
        $allowed = DIUrlShell::doshell();
        $c1 = array_key_exists($do, $allowed) && array_key_exists($func, $allowed[$do]);
        (@$accord = $c1) && count($args) === $allowed[$do][$func];
        if (DIUrlShell::$_strict_mode) {
            $rs = $accord;
        } else {
            $c2 = !$c1 && method_exists($do . 'Do', $func);
            if ($c2) {
                $rm = new ReflectionMethod("{$do}Do::{$func}");
                $needNum = $rm->getNumberOfRequiredParameters();
                $c3 = $needNum <= count($args);
            }
            $rs = $accord || $c2 && $c3;
        }
        return $rs && is_file(DI_DO_PATH . $do . '.do.php');
    }

    private function cmplet($path) {
        $allowed = DIUrlShell::letshell();
        array_walk($allowed, function (&$item, $key) {
            $item = str_replace('|', '/', $item);
        });
        return true;
    }

}
invoke_method($r = new DIRoute(), 'route', array(
    ref_arr($_GET)
));