<?php
/**
 * 参照__env.php建议，按己所需，重新定制特性
 */

define('DI_FILTRATE_DOPARAMS', true);

define('DI_IO_RWFUNC_ENABLE', true);

define('DI_VIEW_AUTOLOAD', false);//待实现

define('DI_SMARTY_ENABLE', false);