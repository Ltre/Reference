<?php 
echo DI_EXT_PATH . 'i/i.php<br>'
?>