<?php 
echo DI_EXT_PATH . 'i/i/i.php<br>'
?>