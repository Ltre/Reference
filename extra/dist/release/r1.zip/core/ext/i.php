<?php 
echo DI_EXT_PATH . 'i.php<br>';
?>