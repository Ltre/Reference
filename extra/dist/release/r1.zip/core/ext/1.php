<?php
echo DI_EXT_PATH . '1.php';