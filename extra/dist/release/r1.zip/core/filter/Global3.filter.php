<?php
class Global3Filter implements DIFilter {
    
    public function doFilter() {
        echo '------------全局过滤器Global3Filter::doFilter()执行------------<br>';
    }

}