<?php
class YyyFilter implements DIFilter {
    
    function doFilter(){
        echo '===============Yyy过滤器执行===============<br>';
    }
    
}