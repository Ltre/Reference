<?php 
echo DI_LET_PATH . 'i/i/i.php<br>'
?>