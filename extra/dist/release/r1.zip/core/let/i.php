<?php 
echo DI_LET_PATH . 'i.php<br>'
?>