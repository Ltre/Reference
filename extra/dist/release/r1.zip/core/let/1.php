<?php
echo DI_LET_PATH . '1.php<br>';