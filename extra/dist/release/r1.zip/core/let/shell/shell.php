<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>DoInject Shell Console - LTRE LAB</title>
<script type="text/javascript" src="res/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="res/js/di.js"></script>
</head>
<body>

<audio id="di-bgm" src="http://data3.5sing.kgimg.com/T1Q3djB4_T1R47IVrK.mp3" autoplay loop ></audio>

<!-- 注意：这段脚本必须放这里！否则会看到CSS延迟加载的情况 -->
<script type="text/javascript">
var nowWidth = document.body.offsetWidth;//当前整个屏幕宽度
var stWidth = 1920;//设计CSS时的可见宽度
var rate = parseFloat(nowWidth) / parseFloat(stWidth) * 100;
var themeUrl = '?||shell|shell-css&rate=' + rate;
(function addCssByLink(url){
    var doc = document;
    var link = doc.createElement("link");
    link.setAttribute("rel", "stylesheet");
    link.setAttribute("type", "text/css");
    link.setAttribute("href", url);
    var heads = doc.getElementsByTagName("head");
    if(heads.length)
        heads[0].appendChild(link);  
    else
        doc.documentElement.appendChild(link);  
}) (themeUrl);
</script>

<script type="text/javascript">
$('body').append('\
<!-- 显示器区域 1280*690 gap=20 -->\
<div id="screen" class="rdall">\
    <!-- 900*600 -->\
    <div id="content">\
    	<!-- 896*596 -->\
        <iframe id="iframepage" class="rdall" src="about:blank"></iframe>\
    </div>\
    <!-- 360*600 -->\
    <div id="overview">\
    	<!-- 340*270 -->\
    	<div id="shellarea" class="rdright"></div>\
        <div id="shellarea" class="rdright"></div>\
    </div>\
    <!-- 1240*20 -->\
    <input id="command" class="rdall" type="text" />\
</div>\
<!-- 支架 -->\
<div id="bracket">\
	<div id="bracket1"></div>\
    <div id="bracket2"></div>\
    <div id="bracket3"></div>\
</div>\
<!-- 底座 -->\
<div id="pedestal"></div>\
');
</script>

<script type="text/javascript">
Di.init();
$(function(){
    /**
     * 屏幕配置
     */
	$('#command').keyup(function(){
		var src = $(this).val();
		var chars = src.split('');
		for (var i in chars) {
			if ('?' === chars[i] || '/' === chars[i] || '&' == chars[i] || ':' == chars[i] || '.' == chars[i])
				continue;
			chars[i] = encodeURIComponent(chars[i]);
		}
		src = chars.join('');
		$('#iframepage').attr('src', src);
	});
	var focuz = function(){$('#command').focus()};
	$(':not(#command)')
	    .keyup(focuz)
	    .keydown(focuz);

    /**
     * BGM配置
     */
    var di_bgm = [
        {
            'id'    : 1,
            'code'  : '111111111111111',
            'name'  : '',
            'url'   : 'http://data3.5sing.kgimg.com/T1Q3djB4_T1R47IVrK.mp3'
        },
        {
            'id'    : 2,
            'code'  : '111111111111111',
            'name'  : '',
            'url'   : ''
        },
        {
            'id'    : 2,
            'code'  : '111111111111111',
            'name'  : '',
            'url'   : ''
        },
        {
            'id'    : 2,
            'code'  : '111111111111111',
            'name'  : '',
            'url'   : ''
        },
        {
            'id'    : 2,
            'code'  : '111111111111111',
            'name'  : '',
            'url'   : ''
        }
    ];
    $('#di-bgm')
});
</script>

</body>
</html>