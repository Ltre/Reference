<?php
class TesttestDo extends DIDo {
    
    /*
     * 用于在外部测试TestDo的注入器特性的脚本
     * 启动测试脚本：$t = new TesttestDo;$t->test();
     * URL启动：<preurl>?testtest/test
     */
    protected function test(){
        /**
         * 测试DIDo注入器
         */
        $runtime = array(
            'version'	=> '1.1.0',
            'time'		=> time()
        );
        DIRuntime::mergeNewItems($runtime);
        $a = new TestDo();
        $a->test();
        $a->b = 1;
        echo $a->b;
    }
    
}