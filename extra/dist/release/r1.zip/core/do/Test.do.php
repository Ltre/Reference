<?php

class TestDo extends DIDo{
    
    //呵呵，总得有个首页吧..
    public function start(){
        $this->shell();
    }
	
	//设置为protected时即可自动调用__call()
	protected function test(){
	    echo '与TestInject桥接时共享的信息：<br>';
	    var_dump($this->_bridge);
	    echo '<br>';
	    
		$args = func_get_args();
		$on_ret = array_pop($args);//取得环绕注入代码
		
		echo '执行信息：<br>';
		echo 'first_on : ';
		$on_ret['first']();
		
		echo 'this is TestDo::test()<br>';
		
		echo 'second_on : ';
		$on_ret['second']();
		
		for ($i=0;$i<3;$i++){
			echo 'third_on : ';
			$on_ret['third']();
		}
	}
	
	
	//各种小测试
	public function lets(){
	    goto TEST13;
	    
	    TEST1:

	    
	    TEST2:
	    /**
	     * 测试2
	     */
	    create_class(
	    'Nima', true, 'DIBase', 'DIEventListener,DIEvent_CallFuncListener',
	    array(
	    'private $var1;',
	    'public $var2 = "2";'
	    ),
	    array(
	    'function __construct($var1){$this->var1=$var1;}',
	    'public function func1(){echo "this is func1()";}',
	    'protected function _func2(){echo "this is _fun2()";}'
	    )
	    );
	    
	    
	    TEST3:
	    /**
	     * 测试3
	     */
	    session('a', 'aaaaa');
	    import('OrekiUtil.class');
	    OrekiUtil::var_dump_array(session());
	    
	    
	    TEST4:
	    /**
	     * 测试4
	     */
	    $aaa = create_class('AAA')->newInstance()->a = 'a';
	    var_dump($aaa);
	    
	    
	    TEST5:
	    /**
	     * 测试5
	     */
	    $bbb = create_class(
	    'BBB', false, 'DIBase', null, null,
	    array('function __construct($b,$bb,$bbb){$this->b=$b;}')
	    )->newInstance(
	    array('b', 'bb', 'bbb')
	    )->b;
	    var_dump($bbb);
	    
	    TEST6:
	    /**
	     * 测试6：比较继承与不继承DIBase的区别
	     */
	    $ii = create_class('temp1', false, 'DIBase')->newInstance();//已继承
	    $ii->test = function(){echo 'temp1->test()<br>';};
	    $ii->test();
	    $ii = create_class('temp2')->newInstance();//未继承
	    $ii->test = function(){echo 'temp2->test()<br>';};
	    //$ii->test();//错误
	    $f = $ii->test;$f();
	    
	    
	    TEST7:
	    /**
	     * 测试7：单端注入
	     */
	    $obj = create_class(
	    'temp5', false, 'DIBase', null, null,
	    array('function test($a,$b){echo "this is temp5->test()<br>";}')
	    )->newInstance();
	    $obj = inject($obj, 'test', function(){echo 'this is an injectable<br>';});
	    $obj->test(1,2);
	    
	    $obj = create_class(
	    'temp6',false,'DIBase',null,null,
	    array(
	        'function __construct($a){echo "temp6->__construct()<br>";}',
	        'function test(){echo "this is temp6->test()<br>";}'
	    )
	    )->newInstance(array(1));
	    $obj = inject($obj, 'test', function(){echo 'this is a .....<br>';}, array(), true);
	    $obj->test();
	    
	    goto END;
	    
	    TEST8:
	    /**
	     * 测试8：前后注入
	     */
	    $obj = create_class(
	    'temp8', false, 'DIBase', null, null,
	    array('function test(){echo "this is temp8->test()<br>";}')
	    )->newInstance();
	    $obj = inject_full(
	    $obj, 'test',
	    array( function(){echo 'this is an injector before temp8::test()<br>';}, array() ),
	    array( function(){echo 'this is an injector after temp8::test()<br>';}, array() )
	    );
	    $obj->test();
	    
	    goto END;
	    
	    
	    
	    TEST9:
	    import(null, DI_LET_PATH);
	    
	    goto END;
	    
	    
	    
	    TEST10://let小程序测试
	    
	    let(2, 'echo "this is a dymic";');
	    let(2);
	    var_dump(let_exists(2));
	    let(2, null);
	    var_dump(let_exists(2));
	    
	    goto END;
	    
	    
	    TEST11:
	    
	    call_user_func_array(
	    function($asc, &$rs){ while(@$i++<25){$rs .= chr($asc + $i);} $rs=str_shuffle($rs);},
	    array(ord('a'), &$clazz)
	    );
	    $obj = create_class($clazz, false, 'DIBase')->newInstance(array(1,2));
	    var_dump($obj);
	    
	    goto END;
	    
	    
	    TEST12: //测试异常的控制
	    try {
	        create_class('shabi', false, null, null, null, array('function __construct(){throw new DIException("shabi");}'))->newInstance();
	    } catch (Exception $e) {
	        throw $e;
	    }
	    
	    goto END;
	    
	    TEST13://测试无特定义后缀且非ext文件的自动加载，现对entity目录进行实验
	    invoke_method(new Test, 'put');
	    
	    goto END;
	    
	    END:
	}
	
	/* 
	 * @todo 测试一
	 * http://localhost/pub/ActionInvokerPlus/?test/test1/fds/fdsa
	 * http://localhost/pub/ActionInvokerPlus/?test/test1
	 * http://localhost/pub/ActionInvokerPlus/?test/test1/fds
	 */
	function test1(){
	    var_dump(func_get_args());
	    var_dump(DIRuntime::getRuntime());
	}
	
	function time(){
	    echo date('Y-m-d H:i:s', 1410425034);
	}
	
	function template(){
	    $this->abcdefg = '1234567';
	    $this->tpl();//测试本页
	    $this->tpl('test-else');//测试其它页面
	}
	
	function shell(){
	    let('shell/shell');
	}
	
}