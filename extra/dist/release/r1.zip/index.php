<?php
require 'core/system.php';